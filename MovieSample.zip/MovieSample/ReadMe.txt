1) MovieSample & MovieAPI both projects built on .net core 3.1
2) MovieAPI reads sample.json and exposes MovieData API to UI
3) MovieSample consumes MovieData API 
4) Nuget Package Newtonsoft.Json is used to read json string & convert it to c# class