﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MovieSample.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using static MovieSample.Models.ViewModel;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;

namespace MovieSample.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
          
        }

        public async Task<IActionResult> Index(string title_search = "", string sort_by = "", string filter_by = "")
        {
                        
            List<Entry> EntryList = new List<Entry>();

            UriBuilder builder = new UriBuilder("http://localhost:1276/MovieData");
            builder.Query = "title_search="+ title_search + "&sort_by="+ sort_by + "&filter_by=" + filter_by + "";
            try
            {

            using (var client=new HttpClient())
                {
                    // Setting content type.  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    // Initialization.  
                    HttpResponseMessage response = new HttpResponseMessage();
                                       
                    response = await client.GetAsync(builder.Uri);

                    if (response.IsSuccessStatusCode)
                        {
                            // Reading Response.  
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            EntryList = JsonConvert.DeserializeObject<List<Entry>>(apiResponse);
                        }   
                    }

            }
            catch(Exception ex)
            {

            }
            return View(EntryList);
           
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
