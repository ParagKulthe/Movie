﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSample.Models
{
    public class ViewModel
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class PosterArt
        {
            public string url { get; set; }
            public int width { get; set; }
            public int height { get; set; }
        }

        public class Images
        {
          //  [JsonProperty(PropertyName = "Poster Art")]
            public PosterArt PosterArt { get; set; }
        }

        public class Entry
        {
            public string title { get; set; }
            public string description { get; set; }
            public string programType { get; set; }
            public Images images { get; set; }
            public int releaseYear { get; set; }
        }

        public class Root
        {
            public int total { get; set; }
            public List<Entry> entries { get; set; }
        }

    }
}
