﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.SqlServer;
using System.IO;
using System.Linq;


namespace MovieAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MovieDataController : ControllerBase
    {
       
        private readonly ILogger<MovieDataController> _logger;

        public MovieDataController(ILogger<MovieDataController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<ViewModel.Entry> Get(string title_search = "", string sort_by = "", string filter_by = "")
        {
            try
            {
                List<ViewModel.Entry> EntryList = new List<ViewModel.Entry>();
                var folderDetails = Path.Combine(Directory.GetCurrentDirectory(), $"JsonData\\{"sample.json"}");
                var myJsonString = System.IO.File.ReadAllText(folderDetails);
                var items = JsonConvert.DeserializeObject<ViewModel.Root>(myJsonString);
                EntryList = items.entries;

                string order = "Desc";
                string cols = "";

                EntryList =EntryList.
                    Where(a => a.releaseYear >= 2010
                    && ((title_search != null) ? a.title.ToLower().Contains(title_search.ToLower()) : true)
                    && ((filter_by == "All") ? true :
                       (filter_by == "Filter1") ? a.programType == "series" :
                       (filter_by == "Filter2") ? a.programType == "movie" : true)                        
                    ).Take(30).ToList();
                // .OrderByWithDirection(
                //  b=> b.releaseYear
                //(cols == "releaseYear") ? b.releaseYear :
                //(cols == "title") ? b.title : b.releaseYear
                // ,
                // (order == "Asc") ? false : true
                // ).ToList();


                return EntryList;
            }

            catch(Exception ex)
            {
                return null;
            }
        }      
    }
}
