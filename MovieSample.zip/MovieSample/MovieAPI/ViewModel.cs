using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace MovieAPI
{
    public class ViewModel
    {

       public class PosterArt
        {
            public string url { get; set; }
            public int width { get; set; }
            public int height { get; set; }
        }

        public class Images
        {
            [JsonProperty(PropertyName = "Poster Art")]
            public PosterArt PosterArt { get; set; }
        }

        public class Entry
        {
            public string title { get; set; }
            public string description { get; set; }
            public string programType { get; set; }
            public Images images { get; set; }
            public int releaseYear { get; set; }
        }

        public class Root
        {
            public int total { get; set; }
            public List<Entry> entries { get; set; }
        }

       
    }

    public static class FilterExt
    {
        public static IOrderedEnumerable<TSource> OrderByWithDirection<TSource, TKey>
       (this IEnumerable<TSource> source,
        Func<TSource, TKey> keySelector,
        bool descending)
        {
            return descending ? source.OrderByDescending(keySelector)
                              : source.OrderBy(keySelector);
        }

    }
}
